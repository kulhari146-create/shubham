"""
This file contains the implementation of the SSAFC trading strategy.
"""

import pandas as pd

def is_green_ssafc_candle(open_price, high, low, close):
    """
    Checks if a candle is a Green SSAFC Candle.
    - Close > Open
    - Open == Low
    - Body >= 80% of candle range
    - Wick <= 20% of candle range
    """
    if not (close > open_price and open_price == low):
        return False

    body = close - open_price
    candle_range = high - low

    if candle_range == 0:
        return False

    body_percentage = body / candle_range
    wick = high - close
    wick_percentage = wick / candle_range

    return body_percentage >= 0.80 and wick_percentage <= 0.20

def is_red_ssafc_candle(open_price, high, low, close):
    """
    Checks if a candle is a Red SSAFC Candle.
    - Close < Open
    - Open == High
    - Body >= 80% of candle range
    - Wick <= 20% of candle range
    """
    if not (close < open_price and open_price == high):
        return False

    body = open_price - close
    candle_range = high - low

    if candle_range == 0:
        return False

    body_percentage = body / candle_range
    wick = close - low
    wick_percentage = wick / candle_range

    return body_percentage >= 0.80 and wick_percentage <= 0.20

def is_white_area(entry, stoploss, previous_candles_df):
    """
    Checks if the Entry-Stoploss zone has been traded in before.
    """
    trade_zone_high = max(entry, stoploss)
    trade_zone_low = min(entry, stoploss)

    for index, row in previous_candles_df.iterrows():
        candle_high = row['High']
        candle_low = row['Low']
        if max(candle_low, trade_zone_low) < min(candle_high, trade_zone_high):
            return False

    return True

def find_ssafc_trades(candles_df, datr):
    """
    Identifies SSAFC trade opportunities from a DataFrame of candle data.
    """
    trades = []
    for i in range(1, len(candles_df)):
        current_candle = candles_df.iloc[i]
        open_price = current_candle['Open']
        high = current_candle['High']
        low = current_candle['Low']
        close = current_candle['Close']

        entry = 0
        stoploss = 0
        trade_type = None

        if is_green_ssafc_candle(open_price, high, low, close):
            entry = open_price + (0.10 * datr)
            stoploss = open_price - (0.10 * datr)
            trade_type = 'long'
        elif is_red_ssafc_candle(open_price, high, low, close):
            entry = open_price - (0.10 * datr)
            stoploss = open_price + (0.10 * datr)
            trade_type = 'short'

        if trade_type:
            previous_candles = candles_df.iloc[:i]
            if is_white_area(entry, stoploss, previous_candles):
                trades.append({
                    'candle_index': i,
                    'trade_type': trade_type,
                    'entry': entry,
                    'stoploss': stoploss
                })

    return trades
