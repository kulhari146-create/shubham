"""
This file contains tests for the SSAFC trading strategy.
"""

import unittest
import pandas as pd
from ssafc_strategy import is_green_ssafc_candle, is_red_ssafc_candle, is_white_area, find_ssafc_trades

class TestSsfcStrategy(unittest.TestCase):

    def test_is_green_ssafc_candle(self):
        # Valid Green SSAFC
        self.assertTrue(is_green_ssafc_candle(100, 105, 100, 104))
        # Invalid scenarios
        self.assertFalse(is_green_ssafc_candle(100, 105, 100, 100)) # Close not > Open
        self.assertFalse(is_green_ssafc_candle(100, 105, 99, 104)) # Open != Low
        self.assertFalse(is_green_ssafc_candle(100, 105, 100, 102)) # Body < 80%
        self.assertFalse(is_green_ssafc_candle(100, 105, 100, 103.9)) # Body < 80% and Wick > 20%

    def test_is_red_ssafc_candle(self):
        # Valid Red SSAFC
        self.assertTrue(is_red_ssafc_candle(105, 105, 100, 101))
        # Invalid scenarios
        self.assertFalse(is_red_ssafc_candle(105, 105, 100, 105)) # Close not < Open
        self.assertFalse(is_red_ssafc_candle(105, 106, 100, 101)) # Open != High
        self.assertFalse(is_red_ssafc_candle(105, 105, 100, 103)) # Body < 80%
        self.assertFalse(is_red_ssafc_candle(105, 105, 100, 101.1)) # Body < 80% and Wick > 20%

    def test_is_white_area(self):
        previous_candles = pd.DataFrame({
            'High': [95, 110],
            'Low': [90, 108]
        })
        # Valid white area
        self.assertTrue(is_white_area(102, 98, previous_candles))
        # Invalid scenarios
        self.assertFalse(is_white_area(109, 107, previous_candles)) # Previous high is in the zone
        self.assertFalse(is_white_area(92, 88, previous_candles)) # Previous low is in the zone
        self.assertFalse(is_white_area(94, 91, previous_candles)) # Previous candle engulfs the zone

    def test_find_ssafc_trades(self):
        datr = 10
        # Scenario with a long trade
        candles_long = pd.DataFrame({
            'Open': [90, 96, 100],
            'High': [92, 98, 105],
            'Low': [88, 95, 100],
            'Close': [91, 97, 104]
        })
        trades_long = find_ssafc_trades(candles_long, datr)
        self.assertEqual(len(trades_long), 1)
        self.assertEqual(trades_long[0]['trade_type'], 'long')

        # Scenario with a short trade
        candles_short = pd.DataFrame({
            'Open': [110, 112, 105],
            'High': [112, 114, 105],
            'Low': [108, 110, 100],
            'Close': [111, 113, 101]
        })
        trades_short = find_ssafc_trades(candles_short, datr)
        self.assertEqual(len(trades_short), 1)
        self.assertEqual(trades_short[0]['trade_type'], 'short')

        # Scenario with no trades
        candles_none = pd.DataFrame({
            'Open': [100, 100, 100],
            'High': [105, 105, 105],
            'Low': [95, 95, 98],
            'Close': [100, 100, 102]
        })
        trades_none = find_ssafc_trades(candles_none, datr)
        self.assertEqual(len(trades_none), 0)

        # Scenario with a SSAFC candle but no white area
        candles_no_white_area = pd.DataFrame({
            'Open': [100, 100, 100],
            'High': [105, 102, 105],
            'Low': [95, 98, 100],
            'Close': [100, 100, 104]
        })
        trades_no_white_area = find_ssafc_trades(candles_no_white_area, datr)
        self.assertEqual(len(trades_no_white_area), 0)

if __name__ == '__main__':
    unittest.main()
